Notes concernant les fichiers excel de fiches de perso

Vous savez que, outre le JDR sur table, il est possible de faire � distance soit par forum, soit avec un micro, Skype/Teamspeak et Rolistik (moins convivial que sur table, mais bien plus que par forum: � d�faut de pouvoir voir la pizza, on peut entendre les gens m�cher).

Les parties par Rolistik pourraient presque se passer de tout papier ext�rieur, sauf pour la feuille de personnage, de classe, de race et de background, car se sont des JPG. Il faut donc les imprimer pour ensuite �crire dessus. J'ai eu donc id�e de faire une feuille de personnage sur un tableau Exel.

La disposition n'est pas exactement la m�me et certaine cases on des tailles bizarre, mais on s'y retrouve. A la place de toutes les cases pour les �nergies, il y en a que deux : une pour le montant actuel l'autre pour le total. Le nombre de case pour la monnaie a �galement �t� r�duite � trois. Le total des protections se fait automatiquement. Sur la droite, il y a le tableau pour les comp�tences. Il suffit de mettre une croix (un X) � droite de la comp�tence choisi. Pour les autres choix de comp�tence possible moi je mets un O, pratique lors des changements de niveaux. Pour vous donner un exemple, j'ai "converti" l'un vos personnage pr�-tir�, le barbare Warglah.

Cr�dits : Maxoc